1. 安装nulink USB驱动
https://www.nuvoton.com.cn/export/resource-files/en-us--Nu-Link_USB_Driver_V1.11.zip

2.替换原有驱动文件nuvcom.cat和nuvcom.inf
C:\Program Files\Nuvoton Tools\Nu-Link_USB_Driver

3.通过设备管理器更换驱动